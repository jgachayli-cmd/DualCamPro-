#!/usr/bin/env bash
# ==============================================================================
# DualCam Pro – Native iOS IPA Archive & Export Script
# Copyright © 2026 DualCam Pro. All rights reserved.
# ==============================================================================

set -e

PROJECT_NAME="DualCamPro"
SCHEME_NAME="DualCamPro"
CONFIGURATION="Release"
BUILD_DIR="$(pwd)/build"
ARCHIVE_PATH="${BUILD_DIR}/${PROJECT_NAME}.xcarchive"
EXPORT_PATH="${BUILD_DIR}/IPA"
EXPORT_OPTIONS_PLIST="$(pwd)/ExportOptions.plist"

echo "=========================================================="
echo "  DualCam Pro – Building Native iOS IPA Package"
echo "=========================================================="

# Check for macOS and Xcode
if ! command -v xcodebuild &> /dev/null; then
    echo "❌ Error: 'xcodebuild' not found."
    echo "   Building a signed iOS .ipa requires a Mac with Xcode 15+ installed."
    echo ""
    echo "   To build on your Mac:"
    echo "   1. Unzip this project package on macOS"
    echo "   2. Run 'open DualCamPro.xcodeproj' or execute './build_ipa.sh'"
    exit 1
fi

echo "✓ Found Xcode: $(xcodebuild -version | head -n 1)"

# 1. Clean build directory
echo "🧹 Cleaning previous build artifacts..."
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"
mkdir -p "${EXPORT_PATH}"

# 2. Archive
echo "📦 Step 1: Creating Xcode Archive (${CONFIGURATION})..."
xcodebuild clean archive \
    -project "${PROJECT_NAME}.xcodeproj" \
    -scheme "${SCHEME_NAME}" \
    -configuration "${CONFIGURATION}" \
    -destination "generic/platform=iOS" \
    -archivePath "${ARCHIVE_PATH}" \
    -allowProvisioningUpdates \
    CODE_SIGN_STYLE="Automatic"

if [ ! -d "${ARCHIVE_PATH}" ]; then
    echo "❌ Archive failed: ${ARCHIVE_PATH} was not generated."
    exit 1
fi
echo "✓ Archive created successfully at ${ARCHIVE_PATH}"

# 3. Export IPA
echo "🚀 Step 2: Exporting .ipa from Archive using ${EXPORT_OPTIONS_PLIST}..."
xcodebuild -exportArchive \
    -archivePath "${ARCHIVE_PATH}" \
    -exportPath "${EXPORT_PATH}" \
    -exportOptionsPlist "${EXPORT_OPTIONS_PLIST}" \
    -allowProvisioningUpdates

# 4. Verify IPA Output
IPA_FILE=$(find "${EXPORT_PATH}" -name "*.ipa" | head -n 1)

if [ -f "${IPA_FILE}" ]; then
    echo "=========================================================="
    echo "🎉 SUCCESS: Installable iOS IPA generated!"
    echo "   Path: ${IPA_FILE}"
    echo "   File size: $(du -h "${IPA_FILE}" | cut -f1)"
    echo "=========================================================="
    echo ""
    echo "📱 Installation Options:"
    echo "  1. Sideloadly / AltStore: Drag ${IPA_FILE} into Sideloadly or AltServer"
    echo "  2. Apple Configurator: Connect iPhone via USB and drag .ipa"
    echo "  3. Xcode Devices Window: Cmd + Shift + 2 -> Drag .ipa to Installed Apps"
    echo "  4. TestFlight: Upload via Transporter or 'xcrun altool'"
else
    echo "⚠️ Warning: Archive succeeded but IPA file export was skipped."
    echo "   Check team provisioning profile in Xcode Signing & Capabilities."
fi
