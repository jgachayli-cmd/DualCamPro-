//
//  PermissionManager.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import Foundation
import AVFoundation
import Photos
import SwiftUI

public final class PermissionManager: ObservableObject {
    
    @Published public var cameraGranted = false
    @Published public var microphoneGranted = false
    @Published public var photosGranted = false
    @Published public var isFullyAuthorized = false
    
    public init() {
        checkAllPermissions()
    }
    
    public func checkAllPermissions() {
        // Camera
        let camStatus = AVCaptureDevice.authorizationStatus(for: .video)
        cameraGranted = (camStatus == .authorized)
        
        // Microphone
        let micStatus = AVAudioSession.sharedInstance().recordPermission
        microphoneGranted = (micStatus == .granted)
        
        // Photos
        let photoStatus = PHPhotoLibrary.authorizationStatus(for: .readWrite)
        photosGranted = (photoStatus == .authorized || photoStatus == .limited)
        
        isFullyAuthorized = cameraGranted && microphoneGranted && photosGranted
    }
    
    public func requestPermissions(completion: @escaping (Bool) -> Void) {
        // Step 1: Camera
        AVCaptureDevice.requestAccess(for: .video) { [weak self] camGranted in
            DispatchQueue.main.async {
                self?.cameraGranted = camGranted
                
                // Step 2: Microphone
                AVAudioSession.sharedInstance().requestRecordPermission { micGranted in
                    DispatchQueue.main.async {
                        self?.microphoneGranted = micGranted
                        
                        // Step 3: Photos Library
                        PHPhotoLibrary.requestAuthorization(for: .readWrite) { photoStatus in
                            DispatchQueue.main.async {
                                let photoGranted = (photoStatus == .authorized || photoStatus == .limited)
                                self?.photosGranted = photoGranted
                                self?.isFullyAuthorized = (camGranted && micGranted && photoGranted)
                                completion(self?.isFullyAuthorized ?? false)
                            }
                        }
                    }
                }
            }
        }
    }
}
