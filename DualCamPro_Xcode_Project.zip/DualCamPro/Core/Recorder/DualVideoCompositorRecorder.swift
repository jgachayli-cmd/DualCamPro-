//
//  DualVideoCompositorRecorder.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import Foundation
import AVFoundation
import CoreImage
import CoreVideo
import UIKit

/// Real-time dual camera stream compositor using AVAssetWriter and Core Image / Metal
public final class DualVideoCompositorRecorder: NSObject {
    
    // MARK: - State & Configuration
    private var isRecording = false
    private var outputURL: URL?
    private var assetWriter: AVAssetWriter?
    private var videoWriterInput: AVAssetWriterInput?
    private var audioWriterInput: AVAssetWriterInput?
    private var pixelBufferAdaptor: AVAssetWriterInputPixelBufferAdaptor?
    
    // Synchronization & Rendering
    private let recordingQueue = DispatchQueue(label: "com.dualcampro.recorderQueue", qos: .userInteractive)
    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])
    
    // Most recent frame buffers for composition
    private var latestBackPixelBuffer: CVPixelBuffer?
    private var latestFrontPixelBuffer: CVPixelBuffer?
    private var latestBackTimestamp: CMTime = .invalid
    private var latestFrontTimestamp: CMTime = .invalid
    private var sessionStartTime: CMTime = .invalid
    
    // Composition Geometry Settings
    private var outputSize: CGSize = CGSize(width: 1920, height: 1080)
    private var pipPosition: PiPPosition = .topRight
    private var pipShape: PiPShape = .roundedRect
    private var pipScale: CGFloat = 1.0
    private var isFrontPrimary: Bool = false
    
    // MARK: - Start Recording
    public func startRecording(
        videoSize: CGSize,
        pipPosition: PiPPosition,
        pipShape: PiPShape,
        pipScale: CGFloat,
        isFrontPrimary: Bool,
        completion: @escaping (Bool, Error?) -> Void
    ) {
        recordingQueue.async { [weak self] in
            guard let self = self else { return }
            
            self.outputSize = videoSize
            self.pipPosition = pipPosition
            self.pipShape = pipShape
            self.pipScale = pipScale
            self.isFrontPrimary = isFrontPrimary
            
            // Unique file path in temporary directory
            let filename = "DualCamPro_\(Date().timeIntervalSince1970).mov"
            let tempDir = FileManager.default.temporaryDirectory
            let fileURL = tempDir.appendingPathComponent(filename)
            self.outputURL = fileURL
            
            // Remove existing file if needed
            try? FileManager.default.removeItem(at: fileURL)
            
            do {
                let writer = try AVAssetWriter(outputURL: fileURL, fileType: .mov)
                self.assetWriter = writer
                
                // 1. Video Input Configuration (HEVC H.265 / H.264)
                let videoSettings: [String: Any] = [
                    AVVideoCodecKey: AVVideoCodecType.hevc,
                    AVVideoWidthKey: Int(videoSize.width),
                    AVVideoHeightKey: Int(videoSize.height),
                    AVVideoCompressionPropertiesKey: [
                        AVVideoAverageBitRateKey: Int(videoSize.width * videoSize.height * 4),
                        AVVideoProfileLevelKey: kVTProfileLevel_HEVC_Main_AutoLevel,
                        AVVideoExpectedSourceFrameRateKey: 30
                    ]
                ]
                
                let vInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
                vInput.expectsMediaDataInRealTime = true
                
                let sourcePixelBufferAttributes: [String: Any] = [
                    kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA),
                    kCVPixelBufferWidthKey as String: Int(videoSize.width),
                    kCVPixelBufferHeightKey as String: Int(videoSize.height),
                    kCVPixelBufferMetalCompatibilityKey as String: true
                ]
                
                let adaptor = AVAssetWriterInputPixelBufferAdaptor(
                    assetWriterInput: vInput,
                    sourcePixelBufferAttributes: sourcePixelBufferAttributes
                )
                
                if writer.canAdd(vInput) {
                    writer.add(vInput)
                    self.videoWriterInput = vInput
                    self.pixelBufferAdaptor = adaptor
                } else {
                    throw NSError(domain: "DualCamPro", code: -1, userInfo: [NSLocalizedDescriptionKey: "Cannot add video writer input"])
                }
                
                // 2. Audio Input Configuration (AAC Stereo 48kHz)
                let audioSettings: [String: Any] = [
                    AVFormatIDKey: kAudioFormatMPEG4AAC,
                    AVNumberOfChannelsKey: 2,
                    AVSampleRateKey: 48000.0,
                    AVEncoderBitRateKey: 192000
                ]
                
                let aInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
                aInput.expectsMediaDataInRealTime = true
                
                if writer.canAdd(aInput) {
                    writer.add(aInput)
                    self.audioWriterInput = aInput
                }
                
                // Reset sync timestamps
                self.sessionStartTime = .invalid
                self.latestBackPixelBuffer = nil
                self.latestFrontPixelBuffer = nil
                self.isRecording = true
                
                completion(true, nil)
            } catch {
                self.isRecording = false
                completion(false, error)
            }
        }
    }
    
    // MARK: - Append Video Sample Buffer
    public func appendVideoSampleBuffer(_ sampleBuffer: CMSampleBuffer, isFrontCamera: Bool) {
        guard isRecording else { return }
        
        recordingQueue.async { [weak self] in
            guard let self = self, self.isRecording else { return }
            guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
            let timestamp = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)
            
            if isFrontCamera {
                self.latestFrontPixelBuffer = imageBuffer
                self.latestFrontTimestamp = timestamp
            } else {
                self.latestBackPixelBuffer = imageBuffer
                self.latestBackTimestamp = timestamp
            }
            
            // Render when the primary camera delivers a frame
            let shouldTriggerRender = self.isFrontPrimary ? isFrontCamera : !isFrontCamera
            if shouldTriggerRender {
                self.compositeAndWriteCurrentFrame(timestamp: timestamp)
            }
        }
    }
    
    // MARK: - Real-Time Frame Compositing
    private func compositeAndWriteCurrentFrame(timestamp: CMTime) {
        guard let writer = assetWriter,
              let adaptor = pixelBufferAdaptor,
              let vInput = videoWriterInput,
              vInput.isReadyForMoreMediaData else {
            return
        }
        
        // Start writer session with first primary frame
        if sessionStartTime == .invalid {
            sessionStartTime = timestamp
            writer.startWriting()
            writer.startSession(atSourceTime: timestamp)
        }
        
        guard writer.status == .writing else { return }
        
        // Identify primary and secondary feeds
        let primaryPixelBuffer = isFrontPrimary ? latestFrontPixelBuffer : latestBackPixelBuffer
        let secondaryPixelBuffer = isFrontPrimary ? latestBackPixelBuffer : latestFrontPixelBuffer
        
        guard let mainBuffer = primaryPixelBuffer else { return }
        
        // Build Core Image composite
        var mainCI = CIImage(cvPixelBuffer: mainBuffer)
        
        // Scale primary image to fill output canvas
        let mainExtent = mainCI.extent
        let scaleX = outputSize.width / mainExtent.width
        let scaleY = outputSize.height / mainExtent.height
        let mainScale = max(scaleX, scaleY)
        mainCI = mainCI.transformed(by: CGAffineTransform(scaleX: mainScale, y: mainScale))
        
        // Center crop primary to output canvas
        let croppedMain = mainCI.cropped(to: CGRect(origin: .zero, size: outputSize))
        
        var finalImage = croppedMain
        
        // Overlay secondary PiP camera stream
        if let secBuffer = secondaryPixelBuffer {
            var pipCI = CIImage(cvPixelBuffer: secBuffer)
            
            if pipPosition == .splitScreen {
                // Split 50/50 Screen Mode
                let halfWidth = outputSize.width / 2
                let leftRect = CGRect(x: 0, y: 0, width: halfWidth, height: outputSize.height)
                let rightRect = CGRect(x: halfWidth, y: 0, width: halfWidth, height: outputSize.height)
                
                let leftCI = croppedMain.cropped(to: leftRect)
                
                let secExtent = pipCI.extent
                let secScale = max(halfWidth / secExtent.width, outputSize.height / secExtent.height)
                let scaledSec = pipCI.transformed(by: CGAffineTransform(scaleX: secScale, y: secScale))
                    .transformed(by: CGAffineTransform(translationX: halfWidth, y: 0))
                    .cropped(to: rightRect)
                
                finalImage = scaledSec.composited(over: leftCI)
            } else {
                // Floating PiP Mode
                let pipWidth = (outputSize.width * 0.28) * pipScale
                let pipHeight = (outputSize.height * 0.28) * pipScale
                let margin: CGFloat = 40.0
                
                var pipOriginX: CGFloat = outputSize.width - pipWidth - margin
                var pipOriginY: CGFloat = outputSize.height - pipHeight - margin
                
                switch pipPosition {
                case .topLeft:
                    pipOriginX = margin
                    pipOriginY = outputSize.height - pipHeight - margin
                case .topRight:
                    pipOriginX = outputSize.width - pipWidth - margin
                    pipOriginY = outputSize.height - pipHeight - margin
                case .bottomLeft:
                    pipOriginX = margin
                    pipOriginY = margin + 120 // Clearance for controls
                case .bottomRight:
                    pipOriginX = outputSize.width - pipWidth - margin
                    pipOriginY = margin + 120
                case .splitScreen:
                    break
                }
                
                let pipRect = CGRect(x: pipOriginX, y: pipOriginY, width: pipWidth, height: pipHeight)
                
                // Scale secondary image to fit PiP
                let secExtent = pipCI.extent
                let pScaleX = pipWidth / secExtent.width
                let pScaleY = pipHeight / secExtent.height
                let pScale = max(pScaleX, pScaleY)
                
                pipCI = pipCI.transformed(by: CGAffineTransform(scaleX: pScale, y: pScale))
                    .cropped(to: CGRect(origin: .zero, size: CGSize(width: pipWidth, height: pipHeight)))
                    .transformed(by: CGAffineTransform(translationX: pipOriginX, y: pipOriginY))
                
                finalImage = pipCI.composited(over: finalImage)
            }
        }
        
        // Render composite directly into pixel buffer pool
        guard let pool = adaptor.pixelBufferPool else { return }
        var renderedBuffer: CVPixelBuffer?
        let status = CVPixelBufferPoolCreatePixelBuffer(kCFAllocatorDefault, pool, &renderedBuffer)
        
        guard status == kCVReturnSuccess, let outputPixelBuffer = renderedBuffer else { return }
        
        ciContext.render(finalImage, to: outputPixelBuffer, bounds: CGRect(origin: .zero, size: outputSize), colorSpace: CGColorSpaceCreateDeviceRGB())
        
        adaptor.append(outputPixelBuffer, withPresentationTime: timestamp)
    }
    
    // MARK: - Append Audio Sample Buffer
    public func appendAudioSampleBuffer(_ sampleBuffer: CMSampleBuffer) {
        guard isRecording,
              let writer = assetWriter,
              writer.status == .writing,
              let aInput = audioWriterInput,
              aInput.isReadyForMoreMediaData,
              sessionStartTime != .invalid else {
            return
        }
        
        recordingQueue.async {
            aInput.append(sampleBuffer)
        }
    }
    
    // MARK: - Stop Recording & Finalize
    public func stopRecording(completion: @escaping (URL?, Error?) -> Void) {
        recordingQueue.async { [weak self] in
            guard let self = self, let writer = self.assetWriter else {
                completion(nil, NSError(domain: "DualCamPro", code: -2, userInfo: [NSLocalizedDescriptionKey: "No active writer"]))
                return
            }
            
            self.isRecording = false
            self.videoWriterInput?.markAsFinished()
            self.audioWriterInput?.markAsFinished()
            
            writer.finishWriting { [weak self] in
                guard let self = self else { return }
                if writer.status == .completed {
                    completion(self.outputURL, nil)
                } else {
                    completion(nil, writer.error)
                }
                self.assetWriter = nil
                self.videoWriterInput = nil
                self.audioWriterInput = nil
                self.pixelBufferAdaptor = nil
            }
        }
    }
}
