//
//  PhotoLibraryManager.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import Foundation
import Photos
import UIKit

public final class PhotoLibraryManager {
    public static let shared = PhotoLibraryManager()
    private let albumName = "DualCam Pro"
    
    private init() {}
    
    public func saveVideoToCameraRoll(url: URL, completion: @escaping (Bool, Error?) -> Void) {
        PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
            guard status == .authorized || status == .limited else {
                let error = NSError(domain: "DualCamPro", code: -3, userInfo: [NSLocalizedDescriptionKey: "Photos access denied"])
                completion(false, error)
                return
            }
            
            PHPhotoLibrary.shared().performChanges({
                // Create video asset request
                let assetRequest = PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
                guard let placeholder = assetRequest?.placeholderForCreatedAsset else { return }
                
                // Fetch or create custom album
                let fetchOptions = PHFetchOptions()
                fetchOptions.predicate = NSPredicate(format: "title = %@", self.albumName)
                let albumCollection = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: fetchOptions)
                
                if let album = albumCollection.firstObject {
                    let albumRequest = PHAssetCollectionChangeRequest(for: album)
                    albumRequest?.addAssets([placeholder] as NSArray)
                } else {
                    let albumRequest = PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle: self.albumName)
                    albumRequest.addAssets([placeholder] as NSArray)
                }
            }) { success, error in
                completion(success, error)
            }
        }
    }
}
