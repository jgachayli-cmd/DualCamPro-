//
//  MultiCamSessionManager.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import Foundation
import AVFoundation
import SwiftUI
import Combine

public enum VideoResolution: String, CaseIterable, Identifiable {
    case hd1080p = "1080p FHD"
    case uhd4K = "4K UHD"
    
    public var id: String { rawValue }
    
    public var dimensions: CMVideoDimensions {
        switch self {
        case .hd1080p:
            return CMVideoDimensions(width: 1920, height: 1080)
        case .uhd4K:
            return CMVideoDimensions(width: 3840, height: 2160)
        }
    }
}

public enum VideoFrameRate: Int, CaseIterable, Identifiable {
    case fps30 = 30
    case fps60 = 60
    
    public var id: Int { rawValue }
    public var title: String { "\(rawValue) FPS" }
}

public enum CameraLens: String, CaseIterable, Identifiable {
    case ultraWide = "0.5x"
    case wide = "1x"
    case telephoto = "3x"
    case superTelephoto = "5x"
    
    public var id: String { rawValue }
}

public enum PiPPosition: String, CaseIterable, Identifiable {
    case topLeft = "Top Left"
    case topRight = "Top Right"
    case bottomLeft = "Bottom Left"
    case bottomRight = "Bottom Right"
    case splitScreen = "Split 50/50"
    
    public var id: String { rawValue }
}

public enum PiPShape: String, CaseIterable, Identifiable {
    case roundedRect = "Rounded"
    case circle = "Circle"
    case pill = "Pill"
    
    public var id: String { rawValue }
}

/// Core Camera Manager coordinating AVCaptureMultiCamSession for dual front/rear streams
public final class MultiCamSessionManager: NSObject, ObservableObject {
    
    // MARK: - Published Properties
    @Published public var isSessionRunning = false
    @Published public var isRecording = false
    @Published public var recordingDuration: TimeInterval = 0
    @Published public var isMultiCamSupported = false
    @Published public var hardwareCost: Float = 0.0
    @Published public var systemPressureLevel: AVCaptureDevice.SystemPressureState.Level = .nominal
    @Published public var activeLens: CameraLens = .wide
    @Published public var activeResolution: VideoResolution = .hd1080p
    @Published public var activeFrameRate: VideoFrameRate = .fps30
    @Published public var pipPosition: PiPPosition = .topRight
    @Published public var pipShape: PiPShape = .roundedRect
    @Published public var pipScale: CGFloat = 1.0 // 0.8x to 1.5x
    @Published public var isFrontPrimary = false // Swap feeds if user wants front full-screen
    @Published public var audioLevels: [Float] = [0.0, 0.0] // L/R VU meters
    @Published public var errorMessage: String?
    @Published public var lastSavedVideoURL: URL?
    @Published public var isTorchOn = false
    @Published public var showGrid = false
    
    // MARK: - AVFoundation Multi-Cam Session
    public let multiCamSession = AVCaptureMultiCamSession()
    private let sessionQueue = DispatchQueue(label: "com.dualcampro.sessionQueue", qos: .userInitiated)
    private let videoDataOutputQueue = DispatchQueue(label: "com.dualcampro.videoQueue", qos: .userInteractive)
    private let audioDataOutputQueue = DispatchQueue(label: "com.dualcampro.audioQueue", qos: .userInteractive)
    
    // Inputs
    private var backCameraInput: AVCaptureDeviceInput?
    private var frontCameraInput: AVCaptureDeviceInput?
    private var audioInput: AVCaptureDeviceInput?
    
    // Outputs
    public let backVideoOutput = AVCaptureVideoDataOutput()
    public let frontVideoOutput = AVCaptureVideoDataOutput()
    public let audioOutput = AVCaptureAudioDataOutput()
    
    // Devices
    private var backCameraDevice: AVCaptureDevice?
    private var frontCameraDevice: AVCaptureDevice?
    
    // Recorder
    public let recorder = DualVideoCompositorRecorder()
    private var recordingTimer: AnyCancellable?
    
    // MARK: - Initialization
    public override init() {
        super.init()
        self.isMultiCamSupported = AVCaptureMultiCamSession.isMultiCamSupported
        self.setupAudioSession()
    }
    
    private func setupAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, mode: .videoRecording, options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true)
        } catch {
            print("Failed to configure audio session: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Session Configuration
    public func configureSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            
            guard AVCaptureMultiCamSession.isMultiCamSupported else {
                DispatchQueue.main.async {
                    self.errorMessage = "MultiCam Capture is not supported on this device. Requires iPhone XS/XR or newer."
                }
                return
            }
            
            self.multiCamSession.beginConfiguration()
            defer { self.multiCamSession.commitConfiguration() }
            
            self.configureBackCamera(lens: self.activeLens)
            self.configureFrontCamera()
            self.configureMicrophone()
            
            self.updateHardwareCost()
        }
    }
    
    // MARK: - Back Camera Setup
    private func configureBackCamera(lens: CameraLens) {
        if let currentInput = backCameraInput {
            multiCamSession.removeInput(currentInput)
        }
        
        let deviceType: AVCaptureDevice.DeviceType
        switch lens {
        case .ultraWide:
            deviceType = .builtInUltraWideCamera
        case .wide:
            deviceType = .builtInWideAngleCamera
        case .telephoto:
            deviceType = .builtInTelephotoCamera
        case .superTelephoto:
            if #available(iOS 17.0, *) {
                deviceType = .builtInTelephotoCamera
            } else {
                deviceType = .builtInTelephotoCamera
            }
        }
        
        guard let device = AVCaptureDevice.default(deviceType, for: .video, position: .back) ??
                AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Could not find back camera device for lens: \(lens)")
            return
        }
        
        self.backCameraDevice = device
        
        do {
            let input = try AVCaptureDeviceInput(device: device)
            guard multiCamSession.canAddInput(input) else {
                print("Cannot add back camera input to multiCamSession")
                return
            }
            multiCamSession.addInputWithNoConnections(input)
            self.backCameraInput = input
            
            // Format & FPS optimization for multi-cam
            selectOptimalFormat(for: device, targetResolution: activeResolution, targetFPS: activeFrameRate)
            
            // Connect to back video output
            if !multiCamSession.outputs.contains(backVideoOutput) {
                backVideoOutput.videoSettings = [
                    kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)
                ]
                backVideoOutput.alwaysDiscardsLateVideoFrames = true
                backVideoOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
                
                guard multiCamSession.canAddOutput(backVideoOutput) else {
                    print("Cannot add back video output")
                    return
                }
                multiCamSession.addOutputWithNoConnections(backVideoOutput)
            }
            
            guard let backPort = input.ports(for: .video, sourceDeviceType: device.deviceType, sourceDevicePosition: .back).first else {
                print("No back camera video port found")
                return
            }
            
            let connection = AVCaptureConnection(inputPorts: [backPort], output: backVideoOutput)
            if multiCamSession.canAddConnection(connection) {
                multiCamSession.addConnection(connection)
                if connection.isVideoOrientationSupported {
                    connection.videoOrientation = .portrait
                }
                if connection.isVideoMirroringSupported {
                    connection.isVideoMirrored = false
                }
            }
        } catch {
            print("Error creating back camera input: \(error)")
        }
    }
    
    // MARK: - Front Camera Setup
    private func configureFrontCamera() {
        if let currentInput = frontCameraInput {
            multiCamSession.removeInput(currentInput)
        }
        
        guard let frontDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
            print("Front camera not available")
            return
        }
        self.frontCameraDevice = frontDevice
        
        do {
            let input = try AVCaptureDeviceInput(device: frontDevice)
            guard multiCamSession.canAddInput(input) else {
                print("Cannot add front camera input")
                return
            }
            multiCamSession.addInputWithNoConnections(input)
            self.frontCameraInput = input
            
            // Format selection for front camera in MultiCam
            selectOptimalFormat(for: frontDevice, targetResolution: .hd1080p, targetFPS: activeFrameRate)
            
            // Connect to front video output
            if !multiCamSession.outputs.contains(frontVideoOutput) {
                frontVideoOutput.videoSettings = [
                    kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)
                ]
                frontVideoOutput.alwaysDiscardsLateVideoFrames = true
                frontVideoOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
                
                guard multiCamSession.canAddOutput(frontVideoOutput) else {
                    print("Cannot add front video output")
                    return
                }
                multiCamSession.addOutputWithNoConnections(frontVideoOutput)
            }
            
            guard let frontPort = input.ports(for: .video, sourceDeviceType: frontDevice.deviceType, sourceDevicePosition: .front).first else {
                print("No front camera video port found")
                return
            }
            
            let connection = AVCaptureConnection(inputPorts: [frontPort], output: frontVideoOutput)
            if multiCamSession.canAddConnection(connection) {
                multiCamSession.addConnection(connection)
                if connection.isVideoOrientationSupported {
                    connection.videoOrientation = .portrait
                }
                if connection.isVideoMirroringSupported {
                    connection.isVideoMirrored = true // Mirror front camera preview like Apple Camera
                }
            }
        } catch {
            print("Error creating front camera input: \(error)")
        }
    }
    
    // MARK: - Microphone Setup
    private func configureMicrophone() {
        guard let micDevice = AVCaptureDevice.default(for: .audio) else { return }
        
        do {
            let input = try AVCaptureDeviceInput(device: micDevice)
            if multiCamSession.canAddInput(input) {
                multiCamSession.addInputWithNoConnections(input)
                self.audioInput = input
            }
            
            if !multiCamSession.outputs.contains(audioOutput) {
                audioOutput.setSampleBufferDelegate(self, queue: audioDataOutputQueue)
                if multiCamSession.canAddOutput(audioOutput) {
                    multiCamSession.addOutputWithNoConnections(audioOutput)
                }
            }
            
            if let audioPort = input.ports(for: .audio, sourceDeviceType: micDevice.deviceType, sourceDevicePosition: .unspecified).first {
                let connection = AVCaptureConnection(inputPorts: [audioPort], output: audioOutput)
                if multiCamSession.canAddConnection(connection) {
                    multiCamSession.addConnection(connection)
                }
            }
        } catch {
            print("Error creating audio input: \(error)")
        }
    }
    
    // MARK: - Multi-Cam Format Selection
    private func selectOptimalFormat(for device: AVCaptureDevice, targetResolution: VideoResolution, targetFPS: VideoFrameRate) {
        do {
            try device.lockForConfiguration()
            defer { device.unlockForConfiguration() }
            
            // Filter formats that support multi-cam
            let multiCamFormats = device.formats.filter { $0.isMultiCamSupported }
            
            // Find closest matching format
            let targetDimensions = targetResolution.dimensions
            let bestFormat = multiCamFormats.first(where: { format in
                let dims = CMVideoFormatDescriptionGetDimensions(format.formatDescription)
                let matchesResolution = dims.width >= targetDimensions.width && dims.height >= targetDimensions.height
                let supportsFPS = format.videoSupportedFrameRateRanges.contains(where: {
                    $0.maxFrameRate >= Double(targetFPS.rawValue) && $0.minFrameRate <= Double(targetFPS.rawValue)
                })
                return matchesResolution && supportsFPS
            }) ?? multiCamFormats.first
            
            if let chosenFormat = bestFormat {
                device.activeFormat = chosenFormat
                let frameDuration = CMTime(value: 1, timescale: CMTimeScale(targetFPS.rawValue))
                device.activeVideoMinFrameDuration = frameDuration
                device.activeVideoMaxFrameDuration = frameDuration
            }
        } catch {
            print("Error locking device format: \(error)")
        }
    }
    
    // MARK: - Session Control
    public func startSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if !self.multiCamSession.isRunning {
                self.multiCamSession.startRunning()
                DispatchQueue.main.async {
                    self.isSessionRunning = self.multiCamSession.isRunning
                }
            }
        }
    }
    
    public func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.multiCamSession.isRunning {
                self.multiCamSession.stopRunning()
                DispatchQueue.main.async {
                    self.isSessionRunning = false
                }
            }
        }
    }
    
    // MARK: - Hardware Cost Calculation
    private func updateHardwareCost() {
        let cost = multiCamSession.hardwareCost
        DispatchQueue.main.async {
            self.hardwareCost = cost
            if cost > 1.0 {
                self.errorMessage = "Hardware cost exceeded 100% (\(Int(cost * 100))%). Lowering resolution or frame rate."
            }
        }
    }
    
    // MARK: - Lens Switching
    public func switchLens(to lens: CameraLens) {
        guard activeLens != lens else { return }
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.multiCamSession.beginConfiguration()
            self.activeLens = lens
            self.configureBackCamera(lens: lens)
            self.multiCamSession.commitConfiguration()
            self.updateHardwareCost()
            
            DispatchQueue.main.async {
                self.activeLens = lens
            }
        }
    }
    
    // MARK: - Torch Control
    public func toggleTorch() {
        guard let device = backCameraDevice, device.hasTorch else { return }
        do {
            try device.lockForConfiguration()
            if device.torchMode == .on {
                device.torchMode = .off
                DispatchQueue.main.async { self.isTorchOn = false }
            } else {
                try device.setTorchModeOn(level: 1.0)
                DispatchQueue.main.async { self.isTorchOn = true }
            }
            device.unlockForConfiguration()
        } catch {
            print("Torch error: \(error)")
        }
    }
    
    // MARK: - Recording Controls
    public func startRecording() {
        guard isSessionRunning, !isRecording else { return }
        
        let outputDimensions = activeResolution.dimensions
        let mainSize = CGSize(width: CGFloat(outputDimensions.width), height: CGFloat(outputDimensions.height))
        
        recorder.startRecording(
            videoSize: mainSize,
            pipPosition: pipPosition,
            pipShape: pipShape,
            pipScale: pipScale,
            isFrontPrimary: isFrontPrimary
        ) { [weak self] success, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if success {
                    self.isRecording = true
                    self.recordingDuration = 0
                    self.startTimer()
                } else if let error = error {
                    self.errorMessage = "Failed to start recording: \(error.localizedDescription)"
                }
            }
        }
    }
    
    public func stopRecording() {
        guard isRecording else { return }
        
        stopTimer()
        recorder.stopRecording { [weak self] resultURL, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.isRecording = false
                self.recordingDuration = 0
                
                if let url = resultURL {
                    self.lastSavedVideoURL = url
                    PhotoLibraryManager.shared.saveVideoToCameraRoll(url: url) { success, saveError in
                        DispatchQueue.main.async {
                            if success {
                                print("Successfully saved Dual Capture video to Photos Library")
                            } else if let saveError = saveError {
                                self.errorMessage = "Saved locally but failed to add to Photos: \(saveError.localizedDescription)"
                            }
                        }
                    }
                } else if let error = error {
                    self.errorMessage = "Failed to finalize video: \(error.localizedDescription)"
                }
            }
        }
    }
    
    private func startTimer() {
        recordingTimer = Timer.publish(every: 0.1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                guard let self = self else { return }
                self.recordingDuration += 0.1
            }
    }
    
    private func stopTimer() {
        recordingTimer?.cancel()
        recordingTimer = nil
    }
}

// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate & Audio Delegate
extension MultiCamSessionManager: AVCaptureVideoDataOutputSampleBufferDelegate, AVCaptureAudioDataOutputSampleBufferDelegate {
    
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if output == backVideoOutput {
            recorder.appendVideoSampleBuffer(sampleBuffer, isFrontCamera: false)
        } else if output == frontVideoOutput {
            recorder.appendVideoSampleBuffer(sampleBuffer, isFrontCamera: true)
        } else if output == audioOutput {
            recorder.appendAudioSampleBuffer(sampleBuffer)
            updateAudioMeters(from: sampleBuffer)
        }
    }
    
    private func updateAudioMeters(from sampleBuffer: CMSampleBuffer) {
        // Quick RMS computation for UI audio meter
        guard let blockBuffer = CMSampleBufferGetDataBuffer(sampleBuffer) else { return }
        var length = 0
        var dataPointer: UnsafeMutablePointer<Int8>?
        CMBlockBufferGetDataPointer(blockBuffer, atOffset: 0, lengthAtOffsetOut: nil, totalLengthOut: &length, dataPointerOut: &dataPointer)
        
        guard let rawPointer = dataPointer, length > 0 else { return }
        let samples = rawPointer.withMemoryRebound(to: Int16.self, capacity: length / 2) { ptr in
            Array(UnsafeBufferPointer(start: ptr, count: min(length / 2, 256)))
        }
        
        var sumSquares: Float = 0
        for sample in samples {
            let floatSample = Float(sample) / Float(Int16.max)
            sumSquares += floatSample * floatSample
        }
        let rms = sqrt(sumSquares / Float(samples.count))
        let level = min(max(rms * 4.0, 0.0), 1.0)
        
        DispatchQueue.main.async {
            self.audioLevels = [level, level * 0.95]
        }
    }
}
