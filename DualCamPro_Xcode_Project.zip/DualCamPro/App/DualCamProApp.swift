//
//  DualCamProApp.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import SwiftUI
import AVFoundation

@main
struct DualCamProApp: App {
    @StateObject private var cameraManager = MultiCamSessionManager()
    @StateObject private var permissionManager = PermissionManager()
    
    var body: some Scene {
        WindowGroup {
            CameraView()
                .environmentObject(cameraManager)
                .environmentObject(permissionManager)
                .preferredColorScheme(.dark)
                .statusBar(hidden: true)
                .persistentSystemOverlays(.hidden)
                .onAppear {
                    permissionManager.checkAllPermissions()
                }
        }
    }
}
