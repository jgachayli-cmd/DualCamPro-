//
//  SettingsSheetView.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import SwiftUI
import AVFoundation

struct SettingsSheetView: View {
    @EnvironmentObject var cameraManager: MultiCamSessionManager
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            List {
                // Section 1: Video Format & Resolution
                Section(header: Text("Video Capture Quality").font(.system(size: 12, weight: .bold))) {
                    Picker("Resolution", selection: $cameraManager.activeResolution) {
                        ForEach(VideoResolution.allCases) { res in
                            Text(res.rawValue).tag(res)
                        }
                    }
                    .pickerStyle(.segmented)
                    
                    Picker("Frame Rate", selection: $cameraManager.activeFrameRate) {
                        ForEach(VideoFrameRate.allCases) { fps in
                            Text(fps.title).tag(fps)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                // Section 2: Picture-in-Picture Layout
                Section(header: Text("Picture-in-Picture (PiP)").font(.system(size: 12, weight: .bold))) {
                    Picker("Default Dock Position", selection: $cameraManager.pipPosition) {
                        ForEach(PiPPosition.allCases) { pos in
                            Text(pos.rawValue).tag(pos)
                        }
                    }
                    
                    Picker("PiP Window Shape", selection: $cameraManager.pipShape) {
                        ForEach(PiPShape.allCases) { shape in
                            Text(shape.rawValue).tag(shape)
                        }
                    }
                    .pickerStyle(.segmented)
                }
                
                // Section 3: Camera Assistance
                Section(header: Text("Assistive Tools").font(.system(size: 12, weight: .bold))) {
                    Toggle("Rule of Thirds Grid", isOn: $cameraManager.showGrid)
                }
                
                // Section 4: Hardware & Multi-Cam Diagnostics
                Section(header: Text("AVCaptureMultiCamSession Diagnostics").font(.system(size: 12, weight: .bold))) {
                    HStack {
                        Text("MultiCam Supported")
                        Spacer()
                        Text(cameraManager.isMultiCamSupported ? "Yes (Hardware OK)" : "Unsupported")
                            .foregroundColor(cameraManager.isMultiCamSupported ? .green : .red)
                            .font(.system(size: 14, weight: .semibold))
                    }
                    
                    HStack {
                        Text("Hardware Cost Budget")
                        Spacer()
                        Text("\(Int(cameraManager.hardwareCost * 100))% / 100%")
                            .foregroundColor(cameraManager.hardwareCost > 0.9 ? .orange : .green)
                            .font(.system(size: 14, weight: .semibold, design: .monospaced))
                    }
                    
                    ProgressView(value: min(Double(cameraManager.hardwareCost), 1.0))
                        .tint(cameraManager.hardwareCost > 0.9 ? .orange : .green)
                }
                
                // Section 5: About & Architecture
                Section(header: Text("Architecture & Encoding").font(.system(size: 12, weight: .bold))) {
                    HStack {
                        Text("Video Codec")
                        Spacer()
                        Text("HEVC H.265 10-bit")
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("Audio Codec")
                        Spacer()
                        Text("AAC Stereo 48kHz")
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text("Compositor Engine")
                        Spacer()
                        Text("CoreVideo & AVAssetWriter")
                            .foregroundColor(.gray)
                    }
                }
            }
            .navigationTitle("DualCam Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                    .foregroundColor(.yellow)
                }
            }
        }
    }
}
