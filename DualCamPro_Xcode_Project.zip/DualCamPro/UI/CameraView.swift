//
//  CameraView.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import SwiftUI
import AVFoundation

struct CameraView: View {
    @EnvironmentObject var cameraManager: MultiCamSessionManager
    @EnvironmentObject var permissionManager: PermissionManager
    
    @State private var showSettings = false
    @State private var showVideoPreview = false
    @State private var pipOffset: CGSize = .zero
    @State private var dragTranslation: CGSize = .zero
    @State private var currentScale: CGFloat = 1.0
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.ignoresSafeArea()
                
                if permissionManager.isFullyAuthorized {
                    // MARK: - 1. Full-Screen Primary Camera Preview
                    PrimaryPreviewView(
                        session: cameraManager.multiCamSession,
                        videoOutput: cameraManager.isFrontPrimary ? cameraManager.frontVideoOutput : cameraManager.backVideoOutput
                    )
                    .ignoresSafeArea()
                    .onTapGesture(count: 2) {
                        // Double tap flips primary & secondary feeds
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                            cameraManager.isFrontPrimary.toggle()
                        }
                    }
                    
                    // Grid Overlay
                    if cameraManager.showGrid {
                        CameraGridView()
                            .ignoresSafeArea()
                    }
                    
                    // MARK: - 2. Floating Picture-in-Picture Preview
                    FloatingPiPView(
                        session: cameraManager.multiCamSession,
                        videoOutput: cameraManager.isFrontPrimary ? cameraManager.backVideoOutput : cameraManager.frontVideoOutput,
                        parentSize: geometry.size
                    )
                    
                    // MARK: - 3. Controls & Overlay
                    ControlsOverlayView(
                        showSettings: $showSettings,
                        showVideoPreview: $showVideoPreview
                    )
                    
                } else {
                    // MARK: - Permissions Request Screen
                    PermissionRequestView()
                }
            }
            .onAppear {
                if permissionManager.isFullyAuthorized {
                    cameraManager.configureSession()
                    cameraManager.startSession()
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsSheetView()
                    .environmentObject(cameraManager)
            }
            .sheet(isPresented: $showVideoPreview) {
                if let url = cameraManager.lastSavedVideoURL {
                    VideoPreviewSheetView(videoURL: url)
                }
            }
        }
    }
}

// MARK: - UIViewRepresentable for AVCaptureVideoPreviewLayer
struct PrimaryPreviewView: UIViewRepresentable {
    let session: AVCaptureMultiCamSession
    let videoOutput: AVCaptureVideoDataOutput
    
    func makeUIView(context: Context) -> PreviewUIView {
        let view = PreviewUIView()
        view.videoPreviewLayer.session = session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        return view
    }
    
    func updateUIView(_ uiView: PreviewUIView, context: Context) {}
}

class PreviewUIView: UIView {
    override class var layerClass: AnyClass {
        return AVCaptureVideoPreviewLayer.self
    }
    
    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
        return layer as! AVCaptureVideoPreviewLayer
    }
}

// MARK: - Rule of Thirds Camera Grid
struct CameraGridView: View {
    var body: some View {
        GeometryReader { proxy in
            Path { path in
                let w = proxy.size.width
                let h = proxy.size.height
                
                // Vertical lines
                path.move(to: CGPoint(x: w / 3, y: 0))
                path.addLine(to: CGPoint(x: w / 3, y: h))
                path.move(to: CGPoint(x: 2 * w / 3, y: 0))
                path.addLine(to: CGPoint(x: 2 * w / 3, y: h))
                
                // Horizontal lines
                path.move(to: CGPoint(x: 0, y: h / 3))
                path.addLine(to: CGPoint(x: w, y: h / 3))
                path.move(to: CGPoint(x: 0, y: 2 * h / 3))
                path.addLine(to: CGPoint(x: w, y: 2 * h / 3))
            }
            .stroke(Color.white.opacity(0.2), lineWidth: 0.75)
        }
    }
}

// MARK: - Permission Request Screen
struct PermissionRequestView: View {
    @EnvironmentObject var permissionManager: PermissionManager
    @EnvironmentObject var cameraManager: MultiCamSessionManager
    
    var body: some View {
        VStack(spacing: 24) {
            Image(systemName: "camera.badge.ellipsis")
                .font(.system(size: 64, weight: .thin))
                .foregroundColor(.yellow)
            
            VStack(spacing: 8) {
                Text("DualCam Pro")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                
                Text("Simultaneous Front & Rear 4K Video Capture")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(.gray)
            }
            
            VStack(alignment: .leading, spacing: 16) {
                PermissionRow(
                    icon: "camera.fill",
                    title: "Dual Cameras",
                    subtitle: "Access to front & ultra-wide/telephoto rear lenses",
                    granted: permissionManager.cameraGranted
                )
                PermissionRow(
                    icon: "mic.fill",
                    title: "Stereo Audio",
                    subtitle: "Synchronized microphone recording with spatial audio",
                    granted: permissionManager.microphoneGranted
                )
                PermissionRow(
                    icon: "photo.on.rectangle",
                    title: "Photos Library",
                    subtitle: "Direct export to your Camera Roll and custom albums",
                    granted: permissionManager.photosGranted
                )
            }
            .padding(.horizontal, 24)
            .padding(.vertical, 16)
            .background(Color.white.opacity(0.06))
            .cornerRadius(18)
            
            Button(action: {
                permissionManager.requestPermissions { success in
                    if success {
                        cameraManager.configureSession()
                        cameraManager.startSession()
                    }
                }
            }) {
                Text("Grant Camera & Mic Access")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(Color.yellow)
                    .cornerRadius(14)
            }
            .padding(.horizontal, 24)
            .padding(.top, 12)
        }
        .padding(32)
    }
}

struct PermissionRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let granted: Bool
    
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(granted ? .green : .yellow)
                .frame(width: 32)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            if granted {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundColor(.green)
            }
        }
    }
}
