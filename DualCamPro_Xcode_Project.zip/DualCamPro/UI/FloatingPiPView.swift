//
//  FloatingPiPView.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import SwiftUI
import AVFoundation

struct FloatingPiPView: View {
    @EnvironmentObject var cameraManager: MultiCamSessionManager
    let session: AVCaptureMultiCamSession
    let videoOutput: AVCaptureVideoDataOutput
    let parentSize: CGSize
    
    @State private var dragOffset: CGSize = .zero
    @State private var positionOffset: CGSize = .zero
    @State private var pinchScale: CGFloat = 1.0
    
    // PiP base dimensions
    private var baseWidth: CGFloat {
        let width = min(parentSize.width * 0.32, 160)
        return width * pinchScale
    }
    
    private var baseHeight: CGFloat {
        if cameraManager.pipShape == .circle {
            return baseWidth
        }
        return baseWidth * (16.0 / 9.0)
    }
    
    var body: some View {
        Group {
            if cameraManager.pipPosition == .splitScreen {
                EmptyView() // Split screen handled at layout root
            } else {
                pipContainer
            }
        }
    }
    
    private var pipContainer: some View {
        ZStack(alignment: .topTrailing) {
            // Live Preview Layer
            PrimaryPreviewView(session: session, videoOutput: videoOutput)
                .frame(width: baseWidth, height: baseHeight)
                .clipped()
            
            // Subtle Lens tag
            HStack(spacing: 3) {
                Circle()
                    .fill(cameraManager.isRecording ? Color.red : Color.yellow)
                    .frame(width: 6, height: 6)
                Text(cameraManager.isFrontPrimary ? "REAR" : "FRONT")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 3)
            .background(Color.black.opacity(0.6))
            .clipShape(Capsule())
            .padding(6)
        }
        .frame(width: baseWidth, height: baseHeight)
        .clipShape(pipClipShape)
        .overlay(
            pipBorderShape
                .stroke(Color.white.opacity(0.35), lineWidth: 1.5)
        )
        .shadow(color: Color.black.opacity(0.5), radius: 12, x: 0, y: 6)
        .offset(
            x: positionOffset.x + dragOffset.x,
            y: positionOffset.y + dragOffset.y
        )
        // Drag Gesture with Corner Snapping
        .gesture(
            DragGesture()
                .onChanged { value in
                    dragOffset = value.translation
                }
                .onEnded { value in
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.72)) {
                        positionOffset.x += value.translation.x
                        positionOffset.y += value.translation.y
                        dragOffset = .zero
                        snapToNearestCorner()
                    }
                }
        )
        // Pinch to Resize Gesture
        .gesture(
            MagnificationGesture()
                .onChanged { scale in
                    pinchScale = min(max(scale, 0.75), 1.6)
                }
                .onEnded { _ in
                    cameraManager.pipScale = pinchScale
                }
        )
        .onTapGesture(count: 2) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.7)) {
                cameraManager.isFrontPrimary.toggle()
            }
        }
        .onAppear {
            setupInitialCornerPosition()
        }
    }
    
    private var pipClipShape: some Shape {
        switch cameraManager.pipShape {
        case .roundedRect:
            return AnyShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        case .circle:
            return AnyShape(Circle())
        case .pill:
            return AnyShape(Capsule())
        }
    }
    
    private var pipBorderShape: some Shape {
        switch cameraManager.pipShape {
        case .roundedRect:
            return AnyShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        case .circle:
            return AnyShape(Circle())
        case .pill:
            return AnyShape(Capsule())
        }
    }
    
    private func setupInitialCornerPosition() {
        let margin: CGFloat = 20
        let topSafe: CGFloat = 80
        let bottomSafe: CGFloat = 160
        
        switch cameraManager.pipPosition {
        case .topLeft:
            positionOffset = CGSize(
                x: -parentSize.width / 2 + baseWidth / 2 + margin,
                y: -parentSize.height / 2 + baseHeight / 2 + topSafe
            )
        case .topRight:
            positionOffset = CGSize(
                x: parentSize.width / 2 - baseWidth / 2 - margin,
                y: -parentSize.height / 2 + baseHeight / 2 + topSafe
            )
        case .bottomLeft:
            positionOffset = CGSize(
                x: -parentSize.width / 2 + baseWidth / 2 + margin,
                y: parentSize.height / 2 - baseHeight / 2 - bottomSafe
            )
        case .bottomRight:
            positionOffset = CGSize(
                x: parentSize.width / 2 - baseWidth / 2 - margin,
                y: parentSize.height / 2 - baseHeight / 2 - bottomSafe
            )
        case .splitScreen:
            break
        }
    }
    
    private func snapToNearestCorner() {
        let margin: CGFloat = 20
        let topSafe: CGFloat = 80
        let bottomSafe: CGFloat = 160
        
        let isRight = positionOffset.x >= 0
        let isBottom = positionOffset.y >= 0
        
        let targetX = isRight
            ? (parentSize.width / 2 - baseWidth / 2 - margin)
            : (-parentSize.width / 2 + baseWidth / 2 + margin)
            
        let targetY = isBottom
            ? (parentSize.height / 2 - baseHeight / 2 - bottomSafe)
            : (-parentSize.height / 2 + baseHeight / 2 + topSafe)
        
        positionOffset = CGSize(x: targetX, y: targetY)
        
        if !isRight && !isBottom { cameraManager.pipPosition = .topLeft }
        else if isRight && !isBottom { cameraManager.pipPosition = .topRight }
        else if !isRight && isBottom { cameraManager.pipPosition = .bottomLeft }
        else { cameraManager.pipPosition = .bottomRight }
    }
}

// Helper Shape Erasure
struct AnyShape: Shape {
    private let _path: (CGRect) -> Path
    
    init<S: Shape>(_ shape: S) {
        _path = shape.path(in:)
    }
    
    func path(in rect: CGRect) -> Path {
        _path(rect)
    }
}
