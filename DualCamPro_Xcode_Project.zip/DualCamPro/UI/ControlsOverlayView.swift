//
//  ControlsOverlayView.swift
//  DualCamPro
//
//  Created for DualCam Pro - Native Dual Capture for iPhone 17 Pro & iOS 18+
//  Copyright © 2026 DualCam Pro. All rights reserved.
//

import SwiftUI
import AVFoundation

struct ControlsOverlayView: View {
    @EnvironmentObject var cameraManager: MultiCamSessionManager
    @Binding var showSettings: Bool
    @Binding var showVideoPreview: Bool
    
    var body: some View {
        VStack {
            // MARK: - Top Bar
            HStack(alignment: .center) {
                // Torch Button
                Button(action: {
                    cameraManager.toggleTorch()
                }) {
                    Image(systemName: cameraManager.isTorchOn ? "bolt.fill" : "bolt.slash.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(cameraManager.isTorchOn ? .yellow : .white)
                        .frame(width: 44, height: 44)
                        .background(Color.black.opacity(0.4))
                        .clipShape(Circle())
                }
                
                Spacer()
                
                // Center Recording Timer & Format
                if cameraManager.isRecording {
                    HStack(spacing: 8) {
                        Circle()
                            .fill(Color.red)
                            .frame(width: 8, height: 8)
                        
                        Text(formatDuration(cameraManager.recordingDuration))
                            .font(.system(size: 16, weight: .bold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .background(Color.red.opacity(0.2))
                    .overlay(
                        Capsule().stroke(Color.red.opacity(0.5), lineWidth: 1)
                    )
                    .clipShape(Capsule())
                } else {
                    // Quick Resolution & FPS selector
                    Button(action: {
                        toggleNextFormat()
                    }) {
                        HStack(spacing: 4) {
                            Text(cameraManager.activeResolution == .uhd4K ? "4K" : "HD")
                                .font(.system(size: 13, weight: .heavy))
                            Text("·")
                            Text("\(cameraManager.activeFrameRate.rawValue)")
                                .font(.system(size: 13, weight: .bold))
                        }
                        .foregroundColor(.yellow)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.black.opacity(0.45))
                        .clipShape(Capsule())
                    }
                }
                
                Spacer()
                
                // Settings Button
                Button(action: {
                    showSettings = true
                }) {
                    Image(systemName: "slider.horizontal.3")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 44, height: 44)
                        .background(Color.black.opacity(0.4))
                        .clipShape(Circle())
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            
            Spacer()
            
            // MARK: - Live Audio VU Meter
            if cameraManager.isRecording {
                HStack(spacing: 4) {
                    AudioMeterBar(level: cameraManager.audioLevels.first ?? 0)
                    AudioMeterBar(level: cameraManager.audioLevels.last ?? 0)
                }
                .padding(.bottom, 12)
            }
            
            // MARK: - Lens Selector (0.5x, 1x, 3x, 5x)
            HStack(spacing: 16) {
                ForEach(CameraLens.allCases) { lens in
                    Button(action: {
                        cameraManager.switchLens(to: lens)
                    }) {
                        Text(lens.rawValue)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(cameraManager.activeLens == lens ? .yellow : .white)
                            .frame(width: 38, height: 38)
                            .background(
                                Circle()
                                    .fill(cameraManager.activeLens == lens ? Color.black.opacity(0.6) : Color.black.opacity(0.3))
                            )
                            .overlay(
                                Circle()
                                    .stroke(cameraManager.activeLens == lens ? Color.yellow : Color.clear, lineWidth: 1.5)
                            )
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.35))
            .clipShape(Capsule())
            .padding(.bottom, 24)
            
            // MARK: - Bottom Controls Bar
            HStack(alignment: .center) {
                // Recent Video Thumbnail / Preview Button
                Button(action: {
                    if cameraManager.lastSavedVideoURL != nil {
                        showVideoPreview = true
                    }
                }) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.white.opacity(0.12))
                            .frame(width: 50, height: 50)
                        
                        if cameraManager.lastSavedVideoURL != nil {
                            Image(systemName: "play.circle.fill")
                                .font(.system(size: 24))
                                .foregroundColor(.white)
                        } else {
                            Image(systemName: "photo.on.rectangle")
                                .font(.system(size: 20))
                                .foregroundColor(.gray)
                        }
                    }
                }
                .frame(width: 70)
                
                Spacer()
                
                // Shutter Record Button
                Button(action: {
                    UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                    if cameraManager.isRecording {
                        cameraManager.stopRecording()
                    } else {
                        cameraManager.startRecording()
                    }
                }) {
                    ZStack {
                        // Outer White Ring
                        Circle()
                            .stroke(Color.white, lineWidth: 4)
                            .frame(width: 76, height: 76)
                        
                        // Inner Red Morphing Shape
                        if cameraManager.isRecording {
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.red)
                                .frame(width: 32, height: 32)
                                .transition(.scale)
                        } else {
                            Circle()
                                .fill(Color.red)
                                .frame(width: 64, height: 64)
                                .transition(.scale)
                        }
                    }
                }
                .animation(.spring(response: 0.3, dampingFraction: 0.65), value: cameraManager.isRecording)
                
                Spacer()
                
                // Flip / Swap PiP and Main Feed Button
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                        cameraManager.isFrontPrimary.toggle()
                    }
                }) {
                    Image(systemName: "arrow.triangle.2.circlepath.camera")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 50, height: 50)
                        .background(Color.white.opacity(0.15))
                        .clipShape(Circle())
                }
                .frame(width: 70)
            }
            .padding(.horizontal, 30)
            .padding(.bottom, 36)
        }
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let mins = Int(duration) / 60
        let secs = Int(duration) % 60
        let tenths = Int((duration.truncatingRemainder(dividingBy: 1)) * 10)
        return String(format: "%02d:%02d.%d", mins, secs, tenths)
    }
    
    private func toggleNextFormat() {
        if cameraManager.activeResolution == .hd1080p && cameraManager.activeFrameRate == .fps30 {
            cameraManager.activeFrameRate = .fps60
        } else if cameraManager.activeResolution == .hd1080p && cameraManager.activeFrameRate == .fps60 {
            cameraManager.activeResolution = .uhd4K
            cameraManager.activeFrameRate = .fps30
        } else if cameraManager.activeResolution == .uhd4K && cameraManager.activeFrameRate == .fps30 {
            cameraManager.activeFrameRate = .fps60
        } else {
            cameraManager.activeResolution = .hd1080p
            cameraManager.activeFrameRate = .fps30
        }
    }
}

struct AudioMeterBar: View {
    let level: Float
    
    var body: some View {
        GeometryReader { _ in
            ZStack(alignment: .bottom) {
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.gray.opacity(0.4))
                    .frame(width: 4, height: 36)
                
                RoundedRectangle(cornerRadius: 2)
                    .fill(meterColor)
                    .frame(width: 4, height: CGFloat(level) * 36)
            }
        }
        .frame(width: 4, height: 36)
    }
    
    private var meterColor: Color {
        if level > 0.85 { return .red }
        if level > 0.6 { return .yellow }
        return .green
    }
}
