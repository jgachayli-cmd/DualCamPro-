# DualCam Pro – Native iOS Dual Camera Recording App

**DualCam Pro** is a native iOS camera application inspired by the Dual Capture camera feature on iPhone 17 Pro. It records video simultaneously from the front-facing and rear-facing cameras in real time using Apple's **AVFoundation** (`AVCaptureMultiCamSession`), composites the streams into a single synchronized video file via `AVAssetWriter`, and saves the recording directly to the iPhone Photos Library.

---

## Key Features

- **Simultaneous Dual Camera Recording**: Front camera + Rear camera (Ultra Wide, Wide, Telephoto) operating concurrently via `AVCaptureMultiCamSession`.
- **Floating Picture-in-Picture (PiP)**:
  - Draggable anywhere on the display with spring physics and corner docking.
  - Pinch-to-zoom interactive scaling.
  - Shape customization: Rounded Rectangle, Circle, Pill, or Split 50/50 Screen.
  - Double-tap or flip button to swap primary and secondary camera feeds.
- **Real-Time Video Compositing**:
  - `AVAssetWriter` + `AVAssetWriterInputPixelBufferAdaptor` hardware-accelerated pipeline.
  - Timestamp synchronization using `CMSampleBufferGetPresentationTimeStamp`.
  - Stereo 48kHz AAC microphone recording.
- **Direct Photos Library Export**:
  - Saves directly to iPhone Camera Roll and creates a dedicated "DualCam Pro" album using `PHPhotoLibrary`.
- **Camera Controls & Pro Settings**:
  - 1080p FHD and 4K UHD capture.
  - 30 FPS and 60 FPS support with hardware cost validation (`multiCamSession.hardwareCost`).
  - Lens switching: 0.5x Ultra Wide, 1x Wide, 3x Telephoto, 5x Super Telephoto.
  - Live Audio VU level indicators and precision recording timer.

---

## Project Structure

```
DualCamPro/
├── DualCamPro.xcodeproj/
│   └── project.pbxproj             # Native Xcode project file
├── DualCamPro/
│   ├── App/
│   │   └── DualCamProApp.swift      # SwiftUI App entry & environment setup
│   ├── Core/
│   │   ├── Camera/
│   │   │   └── MultiCamSessionManager.swift # AVCaptureMultiCamSession engine
│   │   ├── Recorder/
│   │   │   └── DualVideoCompositorRecorder.swift # Real-time compositor & AVAssetWriter
│   │   ├── Permissions/
│   │   │   └── PermissionManager.swift  # Camera, Mic & Photos auth flows
│   │   └── Storage/
│   │       └── PhotoLibraryManager.swift # Camera Roll saving & album creation
│   ├── UI/
│   │   ├── CameraView.swift         # Root camera preview with AVCaptureVideoPreviewLayer
│   │   ├── FloatingPiPView.swift    # Draggable, resizable PiP container
│   │   ├── ControlsOverlayView.swift # Shutter button, lens switcher, timer & VU meter
│   │   ├── SettingsSheetView.swift  # Format, resolution, FPS & PiP settings
│   │   └── VideoPreviewSheetView.swift # In-app player & share sheet
│   └── Resources/
│       └── Info.plist               # Camera, mic, and photo library permissions
├── ExportOptions.plist              # Configuration for xcodebuild -exportArchive
├── build_ipa.sh                     # Automated CLI build & IPA export script
└── README.md
```

---

## How to Build & Export the IPA

### Prerequisites
- A Mac running **macOS 14 (Sonoma) or macOS 15 (Sequoia)**.
- **Xcode 15 or Xcode 16** with iOS 17+ SDK.
- An iPhone running **iOS 17.0 or iOS 18+** (iPhone XS/XR or newer required for `AVCaptureMultiCamSession`; iPhone 11 through iPhone 17 Pro supported).

> **Note on Simulators**: `AVCaptureMultiCamSession` requires physical camera hardware. Dual camera capture will not run in the Xcode Simulator; you must run on a physical iPhone.

---

### Option 1: Automated Command-Line IPA Build (Fastest)

1. Open Terminal on your Mac and navigate to this folder:
   ```bash
   cd /path/to/DualCamPro
   ```

2. Make `build_ipa.sh` executable and run it:
   ```bash
   chmod +x build_ipa.sh
   ./build_ipa.sh
   ```

3. The script will:
   - Clean previous build files
   - Build and create `build/DualCamPro.xcarchive`
   - Run `xcodebuild -exportArchive` using `ExportOptions.plist`
   - Output the installable `DualCamPro.ipa` inside `build/IPA/`

---

### Option 2: Build & Archive in Xcode GUI

1. Open `DualCamPro.xcodeproj` in Xcode:
   ```bash
   open DualCamPro.xcodeproj
   ```

2. **Select your Team**:
   - In the left sidebar, click the top **DualCamPro** project icon.
   - Select the **DualCamPro** target.
   - Go to the **Signing & Capabilities** tab.
   - Under **Team**, select your Apple ID (Personal Team works for free, or Apple Developer Team).
   - If needed, change the Bundle Identifier from `com.dualcampro.app` to something unique (e.g. `com.yourname.dualcampro`).

3. **Connect Your iPhone**:
   - Connect your iPhone via USB-C or Lightning.
   - Select your physical device in Xcode's scheme destination dropdown (top bar).

4. **Run Directly on Device**:
   - Press **Cmd + R** to compile, install, and run DualCam Pro directly on your iPhone.
   - On your iPhone, go to **Settings > General > VPN & Device Management** and trust your developer certificate if prompted.

5. **Export the IPA**:
   - In Xcode menu, select **Product > Archive**.
   - Once the Organizer opens with the archive selected, click **Distribute App**.
   - Select **Development** or **Ad Hoc** (or **App Store Connect / TestFlight**).
   - Follow prompts and click **Export**.
   - Xcode will generate a folder containing `DualCamPro.ipa`.

---

## Installing the IPA File

Once you have `DualCamPro.ipa`, you can install it on any compatible iPhone using:

1. **Sideloadly (Mac & Windows)**:
   - Connect iPhone.
   - Drag `DualCamPro.ipa` into Sideloadly.
   - Enter your Apple ID and click **Start**.

2. **AltStore**:
   - Open AltStore on iPhone.
   - Tap **My Apps > '+'**, select `DualCamPro.ipa`.

3. **Apple Configurator / Xcode**:
   - Connect iPhone via USB.
   - Open Xcode -> **Window > Devices and Simulators** (Cmd + Shift + 2).
   - Drag `DualCamPro.ipa` into the **Installed Apps** section.

---

## Apple AVFoundation Technical Details

### Hardware Cost Budget
Apple limits simultaneous camera sessions based on sensor bandwidth and ISP (Image Signal Processor) limits. `AVCaptureMultiCamSession.hardwareCost` returns a value from `0.0` to `1.0`. If total cost exceeds `1.0`, the session will fail to start.

DualCam Pro dynamically selects `isMultiCamSupported` formats:
- 1080p FHD 30/60 FPS uses approx 45%–70% hardware budget.
- 4K UHD on supported Pro models (iPhone 13 Pro through iPhone 17 Pro) uses higher bandwidth, which DualCam Pro verifies before committing session changes.
